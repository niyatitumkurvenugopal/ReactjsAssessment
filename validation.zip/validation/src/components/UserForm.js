import React, { useState } from 'react'
import './style.css'

export default function UserForm(props) {
     const [userData, setuserData] = useState({
       email:'',
         firstName:'',
         lastName:'',
         password:''
     })

     const[emailError,setemailError]=useState("");
     const[firstNameError,setfirstNameError]=useState("");
     const[lastNameError,setlastNameError]=useState("");
     const[passwordError,setpasswordError]=useState("");
     //validation Function 
     //Email validation
     const validateEmail=()=>{
       if(userData.firstName && userData.lastName && userData.password && userData.email){
        let regex = /^\S+@\S+$/;
        if (regex.test(userData.email)){
          setemailError("");
          return true;
        }else{
          setemailError("*Enter valid email-id");        }
        }
          else{
            setemailError("*email-id is required");
        }
          return false
          return false


         
            

     };

     const validateFirstName=()=>{
      if(userData.firstName && userData.lastName && userData.password && userData.email){
       let regex1= /^.{4,10}$/;
       if (regex1.test(userData.firstName)){
         setfirstNameError("");
         return true;
       }else{
         setfirstNameError("*First Name should be minimum 4 and maximum 10 digits");        }
       }
         else{
           setfirstNameError("*First Name is required");
       }
         return false
         return false


        
        

    };

    const validatelastName=()=>{
      if(userData.firstName && userData.lastName && userData.password && userData.email){
       let regex2 = /^.{1,5}$/;
       if (regex2.test(userData.lastName)){
         setlastNameError("");
         return true;
       }else{
         setlastNameError("*Last Name should be minimum 1 and maximum 5 digits");        }
       }
         else{
           setlastNameError("*Last Name is required");
       }
         return false
         return false


        
    
    };

    const validatePassword=()=>{
      if(userData.firstName && userData.lastName && userData.password && userData.email){
       let regex3 = /^[@#](?=.{7,13}$)(?=\w{7,13})(?=[^aeiou_]{7,13})(?=.*[A-Z])(?=.*\d)/;
       if (regex3.test(userData.password)){
         setpasswordError("");
         return true;
       }else{
         setpasswordError("*Enter valid password");        }
       }
         else{
           setpasswordError("*Password is required");
       }
         return false
         return false


        
    

    };
    // console.log(userData);

     let updateUserData=(event)=>{
       setuserData({
         ...userData,
         [event.target.name]:event.target.value,


       });
     };

     let saveData=()=>{
       //do all the validation once valid send data to app
       validateEmail();
       if(validateEmail()){
         //sending data to app(parent)
         props.getUserData(userData);
         //clearing the data
         setuserData({
          email:'',
          firstName:'',
          lastName:'',
          password:''

         });
       }

       validateFirstName();
       if(validateFirstName()){
         //sending data to app(parent)
         props.getUserData(userData);
         //clearing the data
         setuserData({
          email:'',
          firstName:'',
          lastName:'',
          password:''

         });
       }
     

     validatelastName();
     if(validatelastName()){
       //sending data to app(parent)
       props.getUserData(userData);
       //clearing the data
       setuserData({
        email:'',
        firstName:'',
        lastName:'',
        password:''

       });
     }
   

   validatePassword();
   if(validatePassword()){
     //sending data to app(parent)
     props.getUserData(userData);
     //clearing the data
     setuserData({
      email:'',
      firstName:'',
      lastName:'',
      password:''

     });
   }
 };

    return (
        <div className='container'>
          <h2>Login Form</h2>
        {/* <form> */}
        <div class="mb-3">
 
  <input 
  name='email'
  type="email" 
  class="form-control"
  placeholder='Enter Email'
  value={userData.email}
  onChange={(event)=>{updateUserData(event)}}
  />
 {emailError&&<div className='errorMsg'>{emailError}</div>}
  </div>
         <div class="mb-3">
 
         <input 
         
         name='firstName'
         type="email" 
         class="form-control"
         placeholder='Enter First Name'
         value={userData.firstName}
         onChange={(event)=>{updateUserData(event)}}
         />
          {firstNameError&&<div className='errorMsg'>{firstNameError}</div>}
         </div>

         <div class="mb-3">
    
         <input
         name='lastName'
          type="email" 
         class="form-control"
         placeholder='Enter Lasst Name'
         value={userData.lastName}
         onChange={(event)=>{updateUserData(event)}}
         />
         {lastNameError&&<div className='errorMsg'>{lastNameError}</div>}
         </div>
  
  <div class="mb-3">
    
    <input
    name='password'
     type="password" 
     class="form-control"
     placeholder='Enter Password'
     value={userData.password}
     onChange={(event)=>{updateUserData(event)}}
      />
      {passwordError&&<div className='errorMsg'>{passwordError}</div>}
  </div>
  <div class="mb-3 form-check">

    
    
  </div>
  <button type="submit" class="btn btn-primary" onClick={saveData}>Submit</button>
{/* </form> */}
                                               
            
            
            
        </div>
    )
}

