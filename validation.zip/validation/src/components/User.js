import React, { useState } from 'react'
export default function User({user}){
    return(
        <div>
            <h4>{user.email}</h4>
            <h4>{user.firstName}</h4>
            <h4>{user.lastName}</h4>
            <h4>{user.password}</h4>
        </div>
    )
}