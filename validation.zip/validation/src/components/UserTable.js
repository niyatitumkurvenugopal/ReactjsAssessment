import React, { useState } from 'react'
import User from'./User';

export default function UserTable({userFormData}){
    return(
        <div>
            {
                userFormData.map((user,idx)=>{
                    return <User key={idx} user={user}/>
                })
            }
        </div>
    )
}